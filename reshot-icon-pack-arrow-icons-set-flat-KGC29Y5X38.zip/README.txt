This "Arrow Icons Set - Flat" icon pack was downloaded from https://www.reshot.com/free-svg-icons/pack/arrow-icons-set-flat-KGC29Y5X38/ 

Please check the Reshot Icons license available at https://www.reshot.com/license/